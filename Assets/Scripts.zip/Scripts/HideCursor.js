﻿#pragma strict

function Start () {
	Screen.showCursor = false;
}
